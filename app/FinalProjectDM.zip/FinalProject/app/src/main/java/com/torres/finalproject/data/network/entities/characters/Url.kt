package com.torres.finalproject.data.network.entities.characters

data class Url(
    val type: String,
    val url: String
)