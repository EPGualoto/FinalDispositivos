package com.torres.finalproject.data.network.entities.characters

data class Item(
    val name: String,
    val resourceURI: String
)