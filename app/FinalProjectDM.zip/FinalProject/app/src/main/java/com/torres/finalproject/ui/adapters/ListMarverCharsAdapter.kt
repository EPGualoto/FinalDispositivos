package com.torres.finalproject.ui.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.torres.finalproject.R
import com.torres.finalproject.databinding.ItemMarvelCharsBinding
import com.torres.finalproject.ui.entities.marvel.MarvelCharsUI

class ListMarverCharsAdapter :
    ListAdapter<MarvelCharsUI, ListMarverCharsAdapter.MarvelVH>(DiffUtilMarvelCallback) {

    class MarvelVH(view: View) : RecyclerView.ViewHolder(view) {

        private val binding = ItemMarvelCharsBinding.bind(view)

        fun render(item: MarvelCharsUI) {

            binding.imgChars.load(item.image)
            //binding.imgChars.scaleType -->Escalar la imagen
            binding.txtNameChars.text = item.name
            Log.d("IM", item.image.toString())

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MarvelVH {
        val inflater = LayoutInflater.from(parent.context)
        return MarvelVH(
            inflater.inflate(
                R.layout.item_marvel_chars,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MarvelVH, position: Int) {
        holder.render(
            getItem(position)
        )
    }
}

object DiffUtilMarvelCallback : DiffUtil.ItemCallback<MarvelCharsUI>() {
    override fun areItemsTheSame(oldItem: MarvelCharsUI, newItem: MarvelCharsUI):
            Boolean {
        return oldItem.id == newItem.id

    }

    override fun areContentsTheSame(oldItem: MarvelCharsUI, newItem: MarvelCharsUI):
            Boolean {
        return oldItem == newItem
    }

}
