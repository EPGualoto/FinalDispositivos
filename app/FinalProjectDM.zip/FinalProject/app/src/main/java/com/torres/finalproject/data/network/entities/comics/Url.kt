package com.torres.finalproject.data.network.entities.comics

data class Url(
    val type: String,
    val url: String
)