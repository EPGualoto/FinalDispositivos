package com.torres.finalproject.data.network.entities.comics

data class Series(
    val name: String,
    val resourceURI: String
)