package com.torres.finalproject.data.network.repositories

object ApiKeys {

    const val TS_MARVEL = 12
    const val HASH_MARVEL = "e596fc71c5206bf97a03236b1cb1657b"
    const val PUBLIC_KEY_MARVEL = "ac744ff25f1d2f70b0de34ce2b8ea470"
}