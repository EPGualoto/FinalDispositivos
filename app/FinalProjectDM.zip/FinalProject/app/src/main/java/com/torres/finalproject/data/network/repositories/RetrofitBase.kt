package com.torres.finalproject.data.network.repositories

import com.torres.finalproject.data.network.interceptors.MarvelInterceptor
import com.torres.finalproject.data.network.repositories.ApiKeys.HASH_MARVEL
import com.torres.finalproject.data.network.repositories.ApiKeys.PUBLIC_KEY_MARVEL
import com.torres.finalproject.data.network.repositories.ApiKeys.TS_MARVEL
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


object RetrofitBase {


    fun returnBaseRetrofitMarvel(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://gateway.marvel.com:443/v1/public/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(apiClientMarvel())
            .build()
    }

    private fun apiClientMarvel(): OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(
            MarvelInterceptor(
                PUBLIC_KEY_MARVEL,
                TS_MARVEL,
                HASH_MARVEL
            )
        )
        .build()


}