package com.torres.finalproject.data.network.endpoints

import com.torres.finalproject.data.network.entities.characters.MarvelChars
import com.torres.finalproject.data.network.entities.comics.ComicsChar
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface MarvelEndpoint {

    @GET("characters")
    suspend fun getAllcharacters(@Query("limit") limit: Int): Response<MarvelChars>

    @GET("characters/{characterId}")
    suspend fun getOneCharacter(@Path("characterId") id: Int): Response<MarvelChars>

    @GET("characters/{characterId}/comics")
    suspend fun getComicsOneCharacter(@Path("characterId") id: Int): Response<ComicsChar>


}