package com.torres.finalproject.data.network.entities.comics

data class Item(
    val name: String,
    val resourceURI: String
)