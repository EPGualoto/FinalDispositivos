package com.torres.finalproject.ui.entities.marvel

data class MarvelCharsUI(
    val id: Int,
    val name: String,
    val image: String
)