package com.torres.finalproject.logic.marvel

import com.torres.finalproject.data.network.endpoints.MarvelEndpoint
import com.torres.finalproject.data.network.repositories.RetrofitBase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class GetOneCharacterUserCase {
    fun invoke(idChar: Int) = flow{
    //fun invoke(idChar : Int) = flow{
        val response = RetrofitBase.returnBaseRetrofitMarvel()
            .create(MarvelEndpoint::class.java)
            .getOneCharacter(idChar)
        if(response.isSuccessful){
            val a = response.body()?.data?.results
            //transformación, comprobación y un cambio se puede hacer acá
            a?.forEach{
                emit(it)
            }
        }
    }
}