package com.torres.finalproject.data.local.repositories

import android.content.Context
import androidx.room.AutoMigration
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.torres.finalproject.data.local.database.dao.UsersDAO
import com.torres.finalproject.data.local.database.entities.UsersDB

@Database(
    entities = [UsersDB::class],
    version = 2,
    exportSchema = true,
    autoMigrations = [AutoMigration(from = 1, to = 2)]
)
abstract class DataBaseRepository : RoomDatabase() {
    abstract fun getUserDao(): UsersDAO

    companion object {

        @Volatile
        private var dbConnection: DataBaseRepository? = null

        fun getDBConnection(context: Context): DataBaseRepository {
            return dbConnection ?: synchronized(this) {
                val INSTANCE =
                    Room.databaseBuilder(
                        context,
                        DataBaseRepository::class.java,
                        "Datos"
                    ).build()
                dbConnection = INSTANCE
                dbConnection!!
            }
        }
    }
}