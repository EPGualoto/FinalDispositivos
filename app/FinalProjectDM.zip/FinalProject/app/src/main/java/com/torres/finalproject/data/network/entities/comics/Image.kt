package com.torres.finalproject.data.network.entities.comics

data class Image(
    val extension: String,
    val path: String
)