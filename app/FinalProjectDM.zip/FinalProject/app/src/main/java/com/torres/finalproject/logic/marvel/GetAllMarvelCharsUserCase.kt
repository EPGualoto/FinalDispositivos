package com.torres.finalproject.logic.marvel

import android.util.Log
import com.torres.finalproject.data.network.endpoints.MarvelEndpoint
import com.torres.finalproject.data.network.repositories.RetrofitBase
import com.torres.finalproject.ui.core.toMarverCharUI
import com.torres.finalproject.ui.entities.marvel.MarvelCharsUI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class GetAllMarvelCharsUserCase {

    suspend operator fun invoke() = flow {

        var response = RetrofitBase.returnBaseRetrofitMarvel()
            .create(MarvelEndpoint::class.java)
            .getAllcharacters(100)

        if (response.isSuccessful) {

            val x = response.body()?.data?.results
            var items = ArrayList<MarvelCharsUI>()

            x?.forEach {
                items.add(it.toMarverCharUI())
            }
            Log.d("TAG", items.size.toString())
            emit(Result.success(items.toList()))
        }

    }.catch {
        Log.d("TAG", it.message.toString())
        emit(Result.failure(it))
    }.flowOn(Dispatchers.IO)
}