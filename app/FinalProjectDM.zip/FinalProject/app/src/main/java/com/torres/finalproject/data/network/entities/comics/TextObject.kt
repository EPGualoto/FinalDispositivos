package com.torres.finalproject.data.network.entities.comics

data class TextObject(
    val language: String,
    val text: String,
    val type: String
)