package com.torres.finalproject.data.network.entities.comics

data class Price(
    val price: Double,
    val type: String
)