package com.torres.finalproject.ui.fragments.login

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.torres.finalproject.R
import com.torres.finalproject.databinding.FragmentLoginBinding
import com.torres.finalproject.ui.activities.MainActivity
import com.torres.finalproject.ui.core.ManageUIStates
import com.torres.finalproject.ui.viewmodels.login.LoginFragmentVM
import kotlinx.coroutines.launch


class LoginFragment : Fragment() {

    private lateinit var binding: FragmentLoginBinding
    private val loginFragmentVM: LoginFragmentVM by viewModels()
    private lateinit var manageUIState: ManageUIStates

    private lateinit var  auth : FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding =
            FragmentLoginBinding.bind(
                inflater.inflate(
                    R.layout.fragment_login,
                    container, false
                )
            )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initVariables()
        initListeners()
        initObservers()
    }

    private fun initVariables() {
        auth =Firebase.auth
        manageUIState = ManageUIStates(
            requireContext(),
            binding.lytLoading.mainLayout
        )


        val currentUser = auth.currentUser
        if(currentUser !=  null){
            startActivity(Intent(requireActivity(), MainActivity::class.java))

        }
    }

    private fun initObservers() {
        loginFragmentVM.uiState.observe(viewLifecycleOwner) { state ->
            manageUIState.invoke(state)
        }

        loginFragmentVM.idUser.observe(viewLifecycleOwner) { id ->

            startActivity(
                Intent(
                    requireActivity(),
                    MainActivity::class.java
                )
            )
            requireActivity().finish()
        }
    }


    private fun initListeners() {
        binding.btnSigIn.setOnClickListener {
            findNavController().navigate(
                LoginFragmentDirections.actionLoginFragmentToRegisterFragment()
            )
        }

        binding.btnRecoveryAccount.setOnClickListener {
            findNavController().navigate(
                LoginFragmentDirections.actionLoginFragmentToRecoveryFragment()
            )
        }


        binding.btnLogin.setOnClickListener {
            auth.signInWithEmailAndPassword(
                binding.etxtUser.text.toString(),
                binding.etxtPassword.text.toString()
            )
            .addOnCompleteListener(requireActivity()) { task ->
            if (task.isSuccessful) {
                // Sign in success, update UI with the signed-in user's information
                Log.d(ContentValues.TAG, "signInWithEmail:success")
                val user = auth.currentUser
               // startActivity(Intent.requireAcivity(),MainActivity)
            } else {
                // If sign in fails, display a message to the user.
                Log.w(ContentValues.TAG, "signInWithEmail:failure", task.exception)
                Toast.makeText(
                    requireActivity(),
                    task.exception?.message.toString(),
                    Toast.LENGTH_SHORT,
                ).show()
        }

        }
    }
    }


    private fun loginLocal(){
        lifecycleScope.launch {
            loginFragmentVM.getUserFromDB(
                binding.etxtUser.text.toString(),
                binding.etxtPassword.text.toString(),
                requireContext()
            )

    }
}
}