package com.torres.finalproject.ui.viewmodels.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.torres.finalproject.logic.marvel.GetOneCharacterUserCase
import com.torres.finalproject.ui.core.UIStates
import com.torres.finalproject.ui.core.toMarverCharUI
import com.torres.finalproject.ui.entities.marvel.MarvelCharsUI
import kotlinx.coroutines.Dispatchers
import okhttp3.Dispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class DetailCharsVM : ViewModel(){
    //Se debe trabajar con propiedades que la información no se pueda modificar.
    val items get() = _items
    val uiStates get() = _uiState

    private var _items = MutableStateFlow<MarvelCharsUI>(
        MarvelCharsUI(0,"","")
    )
    private var _uiState = MutableLiveData<UIStates>()

    fun invoke(idChar: Int){
        val f = GetOneCharacterUserCase().invoke(idChar)
        viewModelScope.launch {
            _uiState.postValue(UIStates.LoadingState(true))
            f.flowOn(Dispatchers.IO)
                .map { chars ->
                    chars.toMarverCharUI()
                }
                .catch{
                    _uiState.postValue(UIStates.ErrorState(it.message.toString()))
                }
                .collect{
                    _items.value = it
                }
            delay(500)
            _uiState.postValue(UIStates.LoadingState(true))
            }
    }

}

