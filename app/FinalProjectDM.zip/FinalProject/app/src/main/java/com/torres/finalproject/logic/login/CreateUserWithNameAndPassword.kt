package com.torres.finalproject.logic.login

import android.content.Context
import com.torres.finalproject.data.local.repositories.DataBaseRepository
import com.torres.finalproject.data.local.database.entities.UsersDB
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class CreateUserWithNameAndPassword(
    private val context: Context
) {

    fun invoke(
        name: String, password: String
    ) = flow {
        kotlinx.coroutines.delay(3000)
        DataBaseRepository.getDBConnection(context)
            .getUserDao().saveUser(
                listOf(
                    UsersDB(0, name, password)
                )
            )
        emit(Result.success(true))

    }.catch { ex ->
        emit(Result.failure(ex))
    }.flowOn(Dispatchers.IO)
}
