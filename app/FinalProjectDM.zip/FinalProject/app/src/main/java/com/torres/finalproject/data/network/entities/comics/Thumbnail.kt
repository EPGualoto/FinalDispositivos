package com.torres.finalproject.data.network.entities.comics

data class Thumbnail(
    val extension: String,
    val path: String
)