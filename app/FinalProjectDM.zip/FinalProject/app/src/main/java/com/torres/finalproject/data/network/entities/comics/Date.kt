package com.torres.finalproject.data.network.entities.comics

data class Date(
    val date: String,
    val type: String
)