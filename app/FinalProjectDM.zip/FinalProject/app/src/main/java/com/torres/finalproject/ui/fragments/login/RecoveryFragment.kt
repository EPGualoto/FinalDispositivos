package com.torres.finalproject.ui.fragments.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.torres.finalproject.R
import com.torres.finalproject.databinding.FragmentRecoveryBinding

class RecoveryFragment : Fragment() {

    private lateinit var binding: FragmentRecoveryBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentRecoveryBinding.bind(
            inflater.inflate(
                R.layout.fragment_recovery,
                container,
                false
            )
        )
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initListeners()
    }

    private fun initListeners() {
        binding.btnBack.setOnClickListener {
            findNavController()
                .navigate(RecoveryFragmentDirections.actionRecoveryFragmentToLoginFragment())
        }
    }

}