package com.torres.finalproject.data.network.entities.characters

data class Thumbnail(
    val extension: String,
    val path: String
)