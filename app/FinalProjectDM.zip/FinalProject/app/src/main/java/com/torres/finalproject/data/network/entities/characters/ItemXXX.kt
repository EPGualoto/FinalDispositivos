package com.torres.finalproject.data.network.entities.characters

data class ItemXXX(
    val name: String,
    val resourceURI: String,
    val type: String
)