package com.torres.finalproject.data.network.entities.comics

data class Variant(
    val name: String,
    val resourceURI: String
)