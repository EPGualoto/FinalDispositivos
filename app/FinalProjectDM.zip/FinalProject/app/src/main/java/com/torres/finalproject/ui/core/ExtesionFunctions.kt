package com.torres.finalproject.ui.core

import com.torres.finalproject.data.network.entities.characters.Result
import com.torres.finalproject.ui.entities.marvel.MarvelCharsUI

fun Result.toMarverCharUI() = MarvelCharsUI(
    this.id, this.name,
    this.thumbnail.path + "." + this.thumbnail.extension
)